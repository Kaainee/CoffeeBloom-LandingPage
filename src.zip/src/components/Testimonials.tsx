'use client';
import { Container, Row, Col, Card } from 'react-bootstrap';
import Image from 'next/image';
import { FaStar } from 'react-icons/fa';

const testimonialsData = [
  { id: 1, name: 'Sarah Johnson', title: 'CEO, Tech Solutions', comment: 'Kerja sama yang luar biasa! Tim mereka sangat profesional dan berhasil menyelesaikan proyek API kami tepat waktu dengan kualitas yang melebihi ekspektasi.', avatar: '/avatar1.png', rating: 5, },
  { id: 2, name: 'Michael Chen', title: 'Founder, Startup Kreatif', comment: 'Website baru kami yang dibuat dengan Next.js sangat cepat dan modern. Pengalaman pengguna meningkat drastis. Sangat direkomendasikan!', avatar: '/avatar2.png', rating: 5, },
  { id: 3, name: 'Emily Davis', title: 'Marketing Manager', comment: 'Proses development yang transparan dan komunikatif. Mereka benar-benar memahami kebutuhan kami dan memberikan solusi yang efektif.', avatar: '/avatar3.png', rating: 4, },
];

const Testimonials = () => {
  return (
    <section id="testimonials" className="testimonials-section section-light">
      <Container>
        <h2 className="text-center mb-5">Apa Kata Klien Kami</h2>
        <Row className="justify-content-center">
          {testimonialsData.map((testimonial) => (
            <Col key={testimonial.id} md={4} className="mb-4 d-flex">
              <Card className="testimonial-card">
                <Image src={testimonial.avatar} alt={`Avatar of ${testimonial.name}`} width={100} height={100} className="testimonial-avatar" />
                <Card.Body>
                  <Card.Title as="h4" className="mt-4">{testimonial.name}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">{testimonial.title}</Card.Subtitle>
                  <div className="testimonial-rating">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (<FaStar key={i} />))}
                  </div>
                  <blockquote className="testimonial-comment">{testimonial.comment}</blockquote>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
};
export default Testimonials;