'use client';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { FaDatabase, FaCode, FaReact } from 'react-icons/fa';

const Services = () => {
  return (
    <section id="services" className="section-light">
      <Container>
        <h2 className="text-center mb-5">Layanan Kami</h2>
        <Row className="justify-content-center">
          <Col md={4} className="mb-5 d-flex">
          <Card className="content-card text-center">
            <div className="content-icon-wrapper mt-2"><FaDatabase /></div><Card.Body className="pt-4"><Card.Title as="h3" className="content-card-title mb-3">Jasa .NET API</Card.Title><Card.Text>Pengembangan backend yang kuat dan aman dengan menggunakan teknologi .NET Core untuk membangun RESTful API yang scalable.</Card.Text></Card.Body></Card></Col>
          <Col md={4} className="mb-5 d-flex">
          <Card className="content-card text-center">
            <div className="content-icon-wrapper mt-2"><FaCode /></div><Card.Body className="pt-4"><Card.Title as="h3" className="content-card-title mb-3">Classic HTML</Card.Title><Card.Text>Pembuatan website statis yang responsif dan cepat menggunakan HTML5, CSS3, dan JavaScript standar.</Card.Text></Card.Body></Card></Col>
          <Col md={4} className="mb-5 d-flex">
          <Card className="content-card text-center">
            <div className="content-icon-wrapper mt-2"><FaReact /></div><Card.Body className="pt-4"><Card.Title as="h3" className="content-card-title mb-3">Next.js Development</Card.Title><Card.Text>Membangun aplikasi web modern, cepat, dan SEO-friendly dengan framework React terkemuka, Next.js.</Card.Text></Card.Body></Card></Col>
        </Row>
      </Container>
    </section>
  );
};
export default Services;