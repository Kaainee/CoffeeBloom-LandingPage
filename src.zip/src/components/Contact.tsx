'use client';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import { FaMapMarkerAlt, FaEnvelope, FaPhone } from 'react-icons/fa';

const Contact = () => {
  return (
    <section id="contact" className="section-light">
      <Container>
        <h2 className="text-center mb-5">Hubungi Kami</h2>
        <Row>
          <Col md={5} className="mb-4">
            <h3>Informasi Kontak</h3>
            <p>Jangan ragu untuk menghubungi kami melalui detail di bawah ini.</p>
            <div className="d-flex align-items-center mb-3"><FaMapMarkerAlt size={35} className="me-4" style={{color: 'var(--color-sun-primary)'}} /><span>Kampus Politeknik Astra Dormitory, Jalan Gaharu Blok F3 No. 1, Cibatu, Karangbahagia, KAB. BEKASI, KARANGBAHAGIA, JAWA BARAT, ID, 17530</span></div>
            <div className="d-flex align-items-center mb-3"><FaEnvelope size={18} className="me-4" style={{color: 'var(--color-sun-primary)'}} /><span>Kelompok1@gmail.com</span></div>
            <div className="d-flex align-items-center mb-3"><FaPhone size={18} className="me-4" style={{color: 'var(--color-sun-primary)'}} /><span>08123456789</span></div>
          </Col>
          <Col md={7}>
            <h3>Kirim Pesan</h3>
            <Form>
              <Form.Group className="mb-3" controlId="formGroupName"><Form.Label>Nama Anda</Form.Label><Form.Control type="text" placeholder="Masukkan nama" /></Form.Group>
              <Form.Group className="mb-3" controlId="formGroupEmail"><Form.Label>Alamat Email</Form.Label><Form.Control type="email" placeholder="Masukkan email" /></Form.Group>
              <Form.Group className="mb-3" controlId="formGroupMessage"><Form.Label>Pesan</Form.Label><Form.Control as="textarea" rows={4} placeholder="Tulis pesan Anda di sini" /></Form.Group>
              <Button type="submit" className="btn-sunset">Kirim Pesan</Button>
            </Form>
          </Col>
        </Row>
      </Container>
    </section>
  );
};
export default Contact;