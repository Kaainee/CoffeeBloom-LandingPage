// src/components/About.tsx
'use client';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { FaRegBuilding, FaBullseye, FaTasks } from 'react-icons/fa';

const About = () => {
  return (
    <section id="about" className="section-light">
      <Container>
        <h2 className="text-center mb-5">About Us</h2>
        <Row>
          <Col md={4} className="mb-4 d-flex"><Card className="content-card text-center p-4"><div className="content-icon-wrapper"><FaRegBuilding /></div><Card.Body><Card.Title as="h3" className="content-card-title mb-3">Latar Belakang</Card.Title><Card.Text>Kami adalah perusahaan yang berfokus pada pengembangan solusi perangkat lunak modern. Dengan tim yang berpengalaman, kami berkomitmen untuk memberikan produk berkualitas tinggi.</Card.Text></Card.Body></Card></Col>
          <Col md={4} className="mb-4 d-flex"><Card className="content-card text-center p-4"><div className="content-icon-wrapper"><FaBullseye /></div><Card.Body><Card.Title as="h3" className="content-card-title mb-3">Visi Kami</Card.Title><Card.Text>Menjadi perusahaan teknologi terdepan yang dikenal dengan inovasi dan kualitas dalam setiap solusi yang dihadirkan untuk memajukan peradaban.</Card.Text></Card.Body></Card></Col>
          <Col md={4} className="mb-4 d-flex"><Card className="content-card text-center p-4"><div className="content-icon-wrapper"><FaTasks /></div><Card.Body><Card.Title as="h3" className="content-card-title mb-3">Misi Kami</Card.Title><Card.Text>Memberikan layanan terbaik dengan teknologi terkini, membangun hubungan jangka panjang yang baik dengan klien, dan menciptakan lingkungan kerja yang positif.</Card.Text></Card.Body></Card></Col>
        </Row>
      </Container>
    </section>
  );
};
export default About;