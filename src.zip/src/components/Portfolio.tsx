'use client';
import { Container, Row, Col, Card } from 'react-bootstrap';
import Image from 'next/image';

const Portfolio = () => {
  const projects = [
    { id: 1, src: '/project1.png', title: 'Project 1' },
    { id: 2, src: '/project2.png', title: 'Project 2' },
    { id: 3, src: '/project3.png', title: 'Project 3' },
    { id: 4, src: '/project4.png', title: 'Project 4' },
  ];
  return (
    <section id="portfolio" className="section-light">
      <Container>
        <h2 className="text-center mb-5">Portofolio Kami</h2>
        <Row>
          {projects.map((project) => (
            <Col key={project.id} md={4} lg={3} className="mb-4 d-flex">
              <Card className="content-card portfolio-card">
                <div className="portfolio-card-image-wrapper">
                  <Image
                    src={project.src}
                    alt={project.title}
                    fill
                    className="portfolio-image"
                  />
                </div>
                <Card.Body>
                  <Card.Title className="content-card-title text-center">{project.title}</Card.Title>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
};
export default Portfolio;