import { Container } from "react-bootstrap";

export default function Home() {
  return (
    <header id="home" className="hero-image-background">
      <Container className="hero-content text-center">
        <h1 className="text-gold-highlight display-3 fw-bold">
          Freshly Baked!
        </h1>
        <p className="lead fs-4">
          "Setiap roti kami dibuat dengan cinta, kehangatan, dan bahan terbaik.
          Dari adonan pertama hingga panggangan terakhir, kami percaya bahwa
          rasa bahagia dimulai dari gigitan pertama."
        </p>
      </Container>
    </header>
  );
}
