// src/app/contact/page.tsx
import Contact from '@/components/Contact';

export default function ContactPage() {
  return (
    <main>
      <Contact />
    </main>
  );
}